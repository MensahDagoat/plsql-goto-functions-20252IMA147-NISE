  Reflection.

  What I Learned.

This assignment helped me understand PL/SQL and how it is used to work with data in a database. I learned how to use GOTO statements, functions, conditions, and exception handling.

   GOTO Statements.

I learned how GOTO statements can move the program to a specific label. I also learned that some GOTO statements are not allowed. The A4 task showed me that IF and ELSE statements can be used instead of GOTO and are easier to understand.

   Functions.

I created functions to calculate annual salary, years of service, tax, department name, and payroll status. I learned that functions are useful because the same logic can be used many times.

   Testing.

I tested my functions using employee data. The payroll validator correctly identified valid employees and invalid employees, such as an employee with a zero salary and an employee with a future hire date.

   Conclusion.

Overall, this assignment helped me improve my understanding of PL/SQL functions, GOTO statements, and error handling. I also learned the importance of testing my code to make sure it works correctly.
