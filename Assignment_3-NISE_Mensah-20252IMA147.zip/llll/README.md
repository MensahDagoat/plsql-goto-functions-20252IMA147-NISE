  PL/SQL GOTO Statements and Functions.

Name: NISE Mensah.
Student ID: 20252IMA147.

   Project Overview.

This project demonstrates PL/SQL GOTO statements, functions, exception handling, and testing using Oracle Database.

   Database Used.

Oracle Database.

   Project Structure.

  00_setup – Database tables and data.
  01_goto – GOTO tasks.
  02_functions – PL/SQL functions.
  03_tests – Function tests.
  screenshots – Required screenshots.
  docs – Reflection.

   How to Run.

1. Run the setup script.
2. Run the functions.
3. Run the GOTO programs.
4. Run the test scripts.
5. Check the results.

   Completed Tasks.

Part A:

  A1 Number Classifier.
  A2 Salary Review.
  A3 Illegal GOTO and Fix.
  A4 Rewrite Without GOTO.

Part B:

  B1 Annual Salary.
  B2 Years of Service.
  B3 Tax Calculator.
  B4 Department Name.
  B5 Functions in SQL.

Part C:

  C1 Payroll Validator.
  C2 Reflection.

   AI Use;

AI was used to help understand the tasks, write some PL/SQL code, and fix errors. The code was tested in Oracle SQL Developer.
