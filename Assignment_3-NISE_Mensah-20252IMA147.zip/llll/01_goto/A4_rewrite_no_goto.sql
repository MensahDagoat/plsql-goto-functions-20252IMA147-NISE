SET SERVEROUTPUT ON

DECLARE
    v_num NUMBER := 7;
BEGIN
    IF v_num < 0 THEN
        DBMS_OUTPUT.PUT_LINE(v_num || ' is NEGATIVE');

    ELSIF v_num = 0 THEN
        DBMS_OUTPUT.PUT_LINE(v_num || ' is ZERO');

    ELSE
        IF MOD(v_num, 2) = 0 THEN
            DBMS_OUTPUT.PUT_LINE(v_num || ' is POSITIVE and EVEN');
        ELSE
            DBMS_OUTPUT.PUT_LINE(v_num || ' is POSITIVE and ODD');
        END IF;
    END IF;

    DBMS_OUTPUT.PUT_LINE('Classification complete.');
END;
/