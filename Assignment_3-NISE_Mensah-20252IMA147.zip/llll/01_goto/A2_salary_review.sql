SET SERVEROUTPUT ON

BEGIN
    FOR r IN (
        SELECT emp_id, first_name, salary
        FROM employees
        ORDER BY emp_id
    ) LOOP

        IF r.salary IS NULL OR r.salary <= 0 THEN
            GOTO invalid_salary;

        ELSIF r.salary < 100000 THEN
            GOTO low_band;

        ELSIF r.salary < 300000 THEN
            GOTO mid_band;

        ELSE
            GOTO high_band;
        END IF;

        <<invalid_salary>>
        DBMS_OUTPUT.PUT_LINE(
            r.first_name || ': INVALID salary - refer to HR'
        );
        GOTO next_emp;

        <<low_band>>
        DBMS_OUTPUT.PUT_LINE(
            r.first_name || ': Low band - eligible for 10% raise'
        );
        GOTO next_emp;

        <<mid_band>>
        DBMS_OUTPUT.PUT_LINE(
            r.first_name || ': Mid band - eligible for 5% raise'
        );
        GOTO next_emp;

        <<high_band>>
        DBMS_OUTPUT.PUT_LINE(
            r.first_name || ': High band - no raise this cycle'
        );

        <<next_emp>>
        NULL;

    END LOOP;
END;
/