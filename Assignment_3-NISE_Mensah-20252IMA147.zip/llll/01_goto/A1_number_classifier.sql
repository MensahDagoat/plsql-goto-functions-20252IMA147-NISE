SET SERVEROUTPUT ON

DECLARE
    v_num NUMBER := 7;
BEGIN
    IF v_num < 0 THEN
        GOTO negative_num;
    ELSIF v_num = 0 THEN
        GOTO zero_num;
    ELSE
        GOTO positive_num;
    END IF;

    <<negative_num>>
    DBMS_OUTPUT.PUT_LINE(v_num || ' is NEGATIVE');
    GOTO done;

    <<zero_num>>
    DBMS_OUTPUT.PUT_LINE(v_num || ' is ZERO');
    GOTO done;

    <<positive_num>>
    IF MOD(v_num, 2) = 0 THEN
        DBMS_OUTPUT.PUT_LINE(v_num || ' is POSITIVE and EVEN');
    ELSE
        DBMS_OUTPUT.PUT_LINE(v_num || ' is POSITIVE and ODD');
    END IF;

    <<done>>
    DBMS_OUTPUT.PUT_LINE('Classification complete.');
END;
/