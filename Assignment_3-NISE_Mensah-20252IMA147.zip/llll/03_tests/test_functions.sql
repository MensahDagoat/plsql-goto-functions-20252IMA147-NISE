SET SERVEROUTPUT ON

BEGIN
    DBMS_OUTPUT.PUT_LINE('B1 Annual Salary: ' || fn_annual_salary(201));
    DBMS_OUTPUT.PUT_LINE('B2 Years of Service: ' || fn_years_of_service(201));
    DBMS_OUTPUT.PUT_LINE('B3 Tax: ' || fn_calculate_tax(520000));
    DBMS_OUTPUT.PUT_LINE('B4 Department: ' || fn_dept_name(201));
END;
/