SELECT
    emp_id,
    first_name,
    fn_validate_payroll(emp_id) AS payroll_status
FROM employees
ORDER BY emp_id;