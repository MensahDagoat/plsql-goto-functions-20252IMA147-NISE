CREATE TABLE departments (
    dept_id NUMBER PRIMARY KEY,
    dept_name VARCHAR2(50) NOT NULL
);

CREATE TABLE employees (
    emp_id NUMBER PRIMARY KEY,
    first_name VARCHAR2(30),
    last_name VARCHAR2(30),
    dept_id NUMBER REFERENCES departments(dept_id),
    salary NUMBER(10,2),
    hire_date DATE
);

INSERT INTO departments VALUES (10, 'Accounting');
INSERT INTO departments VALUES (20, 'Technology');
INSERT INTO departments VALUES (30, 'Marketing');

INSERT INTO employees VALUES
(201, 'David', 'Niyonzima', 10, 520000, DATE '2017-02-12');

INSERT INTO employees VALUES
(202, 'Sarah', 'Uwimana', 20, 310000, DATE '2020-06-18');

INSERT INTO employees VALUES
(203, 'Kevin', 'Mutesi', 20, 120000, DATE '2023-09-05');

INSERT INTO employees VALUES
(204, 'Linda', 'Iradukunda', 30, 180000, DATE '2016-04-22');

INSERT INTO employees VALUES
(205, 'Patrick', 'Habiyaremye', 10, 275000, DATE '2019-10-14');

INSERT INTO employees VALUES
(206, 'Demo', 'NoDept', NULL, 0, DATE '2023-03-01');

INSERT INTO employees VALUES
(207, 'Demo', 'Future', 10, 95000, SYSDATE + 30);

COMMIT;