CREATE OR REPLACE FUNCTION fn_validate_payroll (
    p_emp_id NUMBER
)
RETURN VARCHAR2
IS
    v_salary employees.salary%TYPE;
    v_dept_id employees.dept_id%TYPE;
    v_hire_date employees.hire_date%TYPE;
BEGIN
    SELECT salary, dept_id, hire_date
    INTO v_salary, v_dept_id, v_hire_date
    FROM employees
    WHERE emp_id = p_emp_id;

    IF v_salary IS NULL OR v_salary <= 0 THEN
        RETURN 'INVALID: Salary must be greater than 0';

    ELSIF v_dept_id IS NULL THEN
        RETURN 'INVALID: Employee has no department';

    ELSIF v_hire_date > SYSDATE THEN
        RETURN 'INVALID: Future hire date';

    ELSE
        RETURN 'VALID';
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'INVALID: Employee not found';
END;
/