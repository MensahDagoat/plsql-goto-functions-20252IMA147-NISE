CREATE OR REPLACE FUNCTION fn_calculate_tax (
    p_salary NUMBER
)
RETURN NUMBER
IS
    v_tax NUMBER;
BEGIN
    IF p_salary <= 100000 THEN
        v_tax := 0;
    ELSIF p_salary <= 300000 THEN
        v_tax := (p_salary - 100000) * 0.10;
    ELSE
        v_tax := (200000 * 0.10) + ((p_salary - 300000) * 0.20);
    END IF;

    RETURN v_tax;
END;
/