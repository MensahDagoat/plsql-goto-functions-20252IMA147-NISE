CREATE OR REPLACE FUNCTION fn_dept_name (
    p_emp_id NUMBER
)
RETURN VARCHAR2
IS
    v_dept_name departments.dept_name%TYPE;
BEGIN
    SELECT d.dept_name
    INTO v_dept_name
    FROM employees e
    JOIN departments d
        ON e.dept_id = d.dept_id
    WHERE e.emp_id = p_emp_id;

    RETURN v_dept_name;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'No Department';
END;
/